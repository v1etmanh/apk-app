# Cat family assets

Created 2026-11-18.

Five transparent PNG visual references were generated with the built-in image_gen tool.
Five simplified, editable vector animations were then drawn and exported using LottieFiles Creator MCP.
The vector artwork follows the references' character identities and colors; it is not a pixel-exact trace.

## Files and actions

- lottie/father.json — orange father in navy suit, adjusting burgundy tie.
- lottie/mother.json — blue-gray British Shorthair mother, three hair clips, money and sparkling eyes.
- lottie/brother.json — calico older brother, purple eye bags, sleepy blink and head nod.
- lottie/kitten.json — golden British Shorthair kitten, mint overalls, sparkling eyes and head tilt.
- lottie/grandpa.json — charcoal British Shorthair grandfather, silver beard, gentle beard-stroking motion.
- references/ — five original transparent PNG references.
- source/reference-prompts.json — final image prompt set.
- source/creator-family.js — source for LottieFiles Creator; run in a NEW document per character, passing params.kind.

## Playback

512 x 512; 30 fps; 90 frames; 3 seconds.
Enable looping in the consuming Lottie player.
Transparent background; no embedded bitmap assets, fonts, or external assets.
The animations are not yet wired into the mobile app.

## Creator documents

- cat-family-father-20261118 (revision 2)
- cat-family-mother-20261118 (revision 1)
- cat-family-brother-20261118 (revision 1)
- cat-family-kitten-20261118 (revision 1)
- cat-family-grandpa-20261118 (revision 1)

## Verification

Creator rendered four sampled poses per character, including blink poses for mother, brother, kitten and grandpa.
Father's tie animation was corrected to use parent-local coordinates.
All five JSON files parse and report 512 x 512, 30 fps, 90 frames, and zero external assets.
Target mobile-player playback has not been tested.

